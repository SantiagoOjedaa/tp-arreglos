package Arreglos;
import java.util.Scanner;
		public class ArrgeloTemperatura {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Ingrese el año: ");
		        System.out.print("Ingrese el mes (1-12): ");
		        int mes = scanner.nextInt();
		        int diasDelMes = obtenerDiasDelMes(mes);
		        double[] temperaturas = new double[diasDelMes];
		        System.out.println("Ingrese las temperaturas máximas diarias:");
		        for (int i = 0; i < diasDelMes; i++) {
		            System.out.print("Día " + (i + 1) + ": ");
		            temperaturas[i] = scanner.nextDouble();
		        }
		        double sumaTemperaturas = 0;
		        double mayorTemperatura = temperaturas[0];
		        double menorTemperatura = temperaturas[0];
		        for (int i = 0; i < temperaturas.length; i++) {
		            sumaTemperaturas += temperaturas[i];
		            if (temperaturas[i] > mayorTemperatura) {
		                mayorTemperatura = temperaturas[i];
		            }
		            if (temperaturas[i] < menorTemperatura) {
		                menorTemperatura = temperaturas[i];
		            }
		        }
		        double promedio = sumaTemperaturas / diasDelMes;
		        System.out.println("\nResultados:");
		        System.out.println("Promedio de temperaturas máximas: " + promedio);
		        System.out.println("Mayor temperatura del mes: " + mayorTemperatura);
		        System.out.println("Menor temperatura del mes: " + menorTemperatura);
		    }

		    public static int obtenerDiasDelMes(int mes) {
		        if (mes == 2) {
		            return 28; 
		        }
		        
		        if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
		            return 31;
		        }
		        
		        return 30;
		    }
		}
