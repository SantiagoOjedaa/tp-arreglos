package Arreglos;
import java.time.LocalDate;
import java.util.Arrays;

public class ArregloCumpleaños {

    public static void main(String[] args) {
        LocalDate[] fechasDeNacimiento = new LocalDate[] {
            LocalDate.of(2002, 4, 15),  // Alumno 1
            LocalDate.of(2005, 6, 25),  // Alumno 2
            LocalDate.of(2003, 4, 15),  // Alumno 3
            LocalDate.of(2000, 5, 10),  // Alumno 4
            LocalDate.of(2005, 6, 25),  // Alumno 5
            LocalDate.of(2001, 12, 1),   // Alumno 6
        };
        System.out.println("Arreglo original:");
        imprimirFechas(fechasDeNacimiento);
        Arrays.sort(fechasDeNacimiento, (f1, f2) -> {
            int comparacionDiaMes = f1.getDayOfYear() - f2.getDayOfYear();
            if (comparacionDiaMes == 0) {
                return f2.getYear() - f1.getYear();
            }
            return comparacionDiaMes;
        });
        System.out.println("\nOrdenado por día de cumpleaños:");
        imprimirFechas(fechasDeNacimiento);
    }
    public static void imprimirFechas(LocalDate[] fechas) {
        for (LocalDate fecha : fechas) {
            System.out.println(fecha);
        }
    }
}
