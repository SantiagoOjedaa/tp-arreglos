package Arreglos;
import java.util.Scanner;
public class ArregloFibonacci {
    public static int[] generarFibonacci(int n) {
        int[] fibonacci = new int[n];
        if (n > 0) fibonacci[0] = 0;  
        if (n > 1) fibonacci[1] = 1;  
        for (int i = 2; i < n; i++) {
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
        }       
        return fibonacci; 
    }  
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el número N de términos de Fibonacci: ");
        int n = scanner.nextInt();
        int[] fibonacciSerie = generarFibonacci(n);
        System.out.println("Los primeros " + n + " números de la serie de Fibonacci son:");
        for (int i = 0; i < n; i++) {
            System.out.print(fibonacciSerie[i] + " ");
        }
        
        scanner.close(); 
    }
}