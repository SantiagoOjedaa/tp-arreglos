package Arreglos;
import java.util.HashMap;
import java.util.Map;

public class ArregloNumeroRepetido {

    public static void main(String[] args) {
        int[] arreglo = {3, 5, 7, 3, 9, 1, 2, 3, 7, 8, 5, 3, 2, 9, 7, 5, 3, 9, 5, 5, 
                         7, 1, 4, 5, 3, 6, 5, 7, 8, 5};
        int valorMasRepetido = encontrarValorMasRepetido(arreglo);
        System.out.println("El valor que más veces se repite es: " + valorMasRepetido);
    }
    public static int encontrarValorMasRepetido(int[] arreglo) {
        Map<Integer, Integer> frecuencia = new HashMap<>();
        for (int num : arreglo) {
            frecuencia.put(num, frecuencia.getOrDefault(num, 0) + 1);
        }
        int valorMasRepetido = arreglo[0];
        int maxFrecuencia = 0;
        for (Map.Entry<Integer, Integer> entry : frecuencia.entrySet()) {
            if (entry.getValue() > maxFrecuencia) {
                maxFrecuencia = entry.getValue();
                valorMasRepetido = entry.getKey();
            }
        }
        return valorMasRepetido;
    }
}
