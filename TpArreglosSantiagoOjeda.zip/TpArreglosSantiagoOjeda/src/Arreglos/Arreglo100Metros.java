package Arreglos;
import java.util.Scanner;
public class Arreglo100Metros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] tiempos = new double[10];
        for (int i = 0; i < tiempos.length; i++) {
            System.out.print("Ingrese el tiempo del alumno " + (i + 1) + " (en segundos): ");
            tiempos[i] = scanner.nextDouble();
        }
        double mayorTiempo = tiempos[0];
        double menorTiempo = tiempos[0];
        for (int i = 1; i < tiempos.length; i++) {
            if (tiempos[i] > mayorTiempo) {
                mayorTiempo = tiempos[i];
            }
            if (tiempos[i] < menorTiempo) {
                menorTiempo = tiempos[i];
            }
        }
        System.out.println("\nEl mayor tiempo registrado es: " + mayorTiempo + " segundos.");
        System.out.println("El menor tiempo registrado es: " + menorTiempo + " segundos.");
	}

}