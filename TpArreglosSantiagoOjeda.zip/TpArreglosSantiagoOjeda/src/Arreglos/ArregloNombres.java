package Arreglos;
public class ArregloNombres {
	public static void main(String[] args) {
        String[] alumnos = {
            "González, Juan", "Pérez, María", "Rodríguez, Luis", 
            "Martínez Gomez, Laura", "Gómez, Ana", "López, Carlos", 
            "Sánchez, Esteban", "Fernández, Beatriz", "Díaz Reguilón, Pedro", 
            "Gutiérrez, Silvia", "Alvarez, Pedro", "Muñoz, Pablo", 
            "Ramírez, Teresa", "Méndez Lisandro, Ricardo", "Salcedo Reyes, Martín", 
            "Castro Espinoza, Felipe", "Vázquez Ceratti, Javier", "Moreno, Julia", 
            "Herrera, Raúl", "Jiménez Castillo, Carolina"
        };
        String alumnoMasLargo = obtenerAlumnoMasLargo(alumnos);
        System.out.println("El alumno con el nombre más largo es: " + alumnoMasLargo);
        System.out.println("\nAlumnos con dos apellidos:");
        listarAlumnosConDosApellidos(alumnos);
    }
    public static String obtenerAlumnoMasLargo(String[] alumnos) {
        String alumnoMasLargo = alumnos[0];
        for (int i = 1; i < alumnos.length; i++) {
            if (alumnos[i].length() > alumnoMasLargo.length()) {
                alumnoMasLargo = alumnos[i];
            }
        }
        return alumnoMasLargo;
    }
    public static void listarAlumnosConDosApellidos(String[] alumnos) {
        for (String alumno : alumnos) {
            String[] partes = alumno.split(", ");
            if (partes.length == 2) {
                String apellido = partes[0];
                if (apellido.split(" ").length == 2) {
                    System.out.println(alumno);
                }
            }
        }
    }
}
