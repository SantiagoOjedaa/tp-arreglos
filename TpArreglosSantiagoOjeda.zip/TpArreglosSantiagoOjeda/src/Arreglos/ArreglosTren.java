package Arreglos;
import java.util.Scanner;
public class ArreglosTren {
	public static void main(String[] args) {

		  String[] estaciones = {
		            "Plaza Once", "Caballito", "Flores", "Floresta", 
		            "Villa Luro", "Liniers", "Ciudadela", "Ramos Mejía", "Haedo", 
		            "Morón", "Castelar", "Ituzaingó", "San Antonio de Padua", "Merlo", 
		            "Paso del Rey", "Moreno"
		        };
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Ingrese el nombre de la estación que desea buscar: ");
		        String estacionBuscada = scanner.nextLine();
		        int index = buscarEstacion(estaciones, estacionBuscada);

		        if (index != -1) {
		            System.out.println("La estación '" + estacionBuscada + "' existe.");
		            System.out.println("Desde Plaza Once: " + index + " estaciones.");
		            System.out.println("Desde Moreno: " + (estaciones.length - index - 1) + " estaciones.");
		        } else {
		            System.out.println("La estación '" + estacionBuscada + "' no existe en la línea Sarmiento.");
		        }
		    }
		    public static int buscarEstacion(String[] estaciones, String estacionBuscada) {
		        for (int i = 0; i < estaciones.length; i++) {
		            if (estaciones[i].equalsIgnoreCase(estacionBuscada)) {
		                return i;
		            }
		        }
		        return -1;
		    }
	}
