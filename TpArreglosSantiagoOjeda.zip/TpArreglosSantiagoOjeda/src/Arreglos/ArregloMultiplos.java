package Arreglos;
public class ArregloMultiplos {
	public static void main(String[] args) {
		   int[] arreglo = new int[20];
	        for (int i = 0; i < arreglo.length; i++) {
	            arreglo[i] = (int) (Math.random() * 100) + 1;
	        }
	        System.out.println("Arreglo generado:");
	        mostrarArreglo(arreglo);
	        int multiplesDe3 = contarMultiplos(arreglo, 3);
	        int multiplesDe4 = contarMultiplos(arreglo, 4);
	        int multiplesDe5 = contarMultiplos(arreglo, 5);
	        System.out.println("\nCantidad de múltiplos de 3: " + multiplesDe3);
	        System.out.println("Cantidad de múltiplos de 4: " + multiplesDe4);
	        System.out.println("Cantidad de múltiplos de 5: " + multiplesDe5);
	    }
	    public static void mostrarArreglo(int[] arreglo) {
	        for (int i = 0; i < arreglo.length; i++) {
	            System.out.print(arreglo[i] + " ");
	        }
	        System.out.println();
	    }
	    public static int contarMultiplos(int[] arreglo, int divisor) {
	        int contador = 0;
	        for (int i = 0; i < arreglo.length; i++) {
	            if (arreglo[i] % divisor == 0) {
	                contador++;
	            }
	        }
	        return contador;
	    }
	}
