package Arreglos;
import java.util.HashMap;
import java.util.Map;

public class ArregloSociosClub {

    public static void main(String[] args) {
        String[] socios = {
            "Ana", "Tobías", "Alejandra", "David", 
            "Eva", "Sofía", "Candela", "Joaquín",
            "Jorge", "Iván", "Elias", "Mateo",
            "Alejandro", "Laura", "Lorenzo", "Luis", "Tomas"
        };
        char letraMasRepetida = encontrarLetraMasRepetida(socios);
        System.out.println("La letra con la que empiezan más nombres es: " + letraMasRepetida);
    }
    public static char encontrarLetraMasRepetida(String[] arreglo) {
        Map<Character, Integer> letraContador = new HashMap<>();
        for (String nombre : arreglo) {
            char primeraLetra = Character.toUpperCase(nombre.charAt(0));
            letraContador.put(primeraLetra, letraContador.getOrDefault(primeraLetra, 0) + 1);
        }
        char letraMasFrecuente = ' ';
        int maxFrecuencia = 0;
        for (Map.Entry<Character, Integer> entry : letraContador.entrySet()) {
            if (entry.getValue() > maxFrecuencia) {
                maxFrecuencia = entry.getValue();
                letraMasFrecuente = entry.getKey();
            }
        }       
        return letraMasFrecuente;
    }
}
